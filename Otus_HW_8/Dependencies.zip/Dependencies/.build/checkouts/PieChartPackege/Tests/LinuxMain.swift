import XCTest

import PieChartPackegeTests

var tests = [XCTestCaseEntry]()
tests += PieChartPackegeTests.allTests()
XCTMain(tests)
