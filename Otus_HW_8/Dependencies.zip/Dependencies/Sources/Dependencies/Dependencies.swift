struct Dependencies {
    var text = "Hello, World!"
}
