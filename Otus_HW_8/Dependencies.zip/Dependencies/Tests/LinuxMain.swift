import XCTest

import DependenciesTests

var tests = [XCTestCaseEntry]()
tests += DependenciesTests.allTests()
XCTMain(tests)
